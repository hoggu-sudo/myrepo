package com.spy.tests;

import java.util.LinkedHashSet;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0006_Add25SongsToPlayList extends TestBase {

	@Test
	public void add25SongsToPlayList() {

		Actions actions = new Actions(driver);
		int count = 0;
		LinkedHashSet<WebElement> set = new LinkedHashSet<WebElement>();
		List<WebElement> song = driver.findElements(By.xpath("//div[contains(@data-testid,'tracklist-row') and contains(@draggable,\"true\")]"));
		set.addAll(song);

		for (WebElement s : set) {
			if (count != 5) {
				actions.contextClick(s).perform();
				click("addToPL_XPATH");
				click("allPL_XPATH");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				count++;
			} else {
				break;
			}
		}

		log.debug("Adding 1st 25 songs to our playlist is completed");
	}

}



//for (WebElement s : set) {
//if (!set.contains(s) && count != 25) {
//	count++;
//} else {
//	break;
//}
//}



//List<WebElement> pls = driver.findElements(By.xpath("///div[@class='cover-art shadow cover-art--with-auto-height']"));
//pls.get(1).click();
