package com.spy.tests;

import java.io.FileReader;

import org.testng.annotations.Test;

import com.opencsv.CSVReader;
import com.spy.base.TestBase;

public class _0011_CSVFileDetails extends TestBase {

	@Test
	public void csvFileDetails() {
		CSVReader reader = null;
		try {
			reader = new CSVReader(new FileReader("C:\\Users\\hemu\\eclipse\\java-2020-062\\spotify\\src\\test\\resources\\excel\\PlaylistSongs.csv"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
