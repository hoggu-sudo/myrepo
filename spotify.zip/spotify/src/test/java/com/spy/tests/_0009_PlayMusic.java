package com.spy.tests;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0009_PlayMusic extends TestBase {

	@Test
	public void PlayMusic() {

		click("playBtn_XPATH");
		Actions actions = new Actions(driver);
		WebElement play = driver.findElement(By.xpath("//div[.='1']"));
		actions.doubleClick(play).perform();		

		List<WebElement> times = driver.findElements(By.xpath("//div[@data-testid='tracklist-row']/descendant::div[8]/descendant::div[2]"));
		
		String timeLength = times.get(1).getText();
	
		int secs = Integer.parseInt(timeLength.substring(0, 1)) * 60;
		secs = secs + Integer.parseInt(timeLength.substring(2));
		long milsec = (secs - 60) * 1000;

		try {
			Thread.sleep(milsec);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		click("pauseBtn_XPATH");
	}
}
