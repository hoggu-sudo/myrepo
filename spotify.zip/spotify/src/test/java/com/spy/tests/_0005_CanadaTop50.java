package com.spy.tests;

import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0005_CanadaTop50 extends TestBase{
	@Test
	public void candaTop50() {
		
		click("search_XPATH");
		click("charts_XPATH");
		click("top50ByCountry_XPATH");
		click("canadaTop50_XPATH");
		
		log.debug("Canada top 50 playlist is created");
	}

}
