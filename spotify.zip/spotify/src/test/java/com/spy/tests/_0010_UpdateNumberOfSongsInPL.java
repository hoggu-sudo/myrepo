package com.spy.tests;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0010_UpdateNumberOfSongsInPL extends TestBase{

	@Test
	public void updateNumberOfSongsInPL() {
		
		String NofSgs = driver.findElement(By.xpath("numSongs_XPATH")).getText();
	
		log.debug("Found the number of songs in playlist" + NofSgs);

	}
}
