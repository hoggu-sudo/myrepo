package com.spy.tests;

import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0007_NavigatePL extends TestBase {

	@Test
	public void NavigatePL() {			
		
		driver.navigate().refresh();
		
		click("yourLibrary_XPATH");
		click("myPL_XPATH");		
	
		log.debug("Navigate your playlist is completed");
	}
}
