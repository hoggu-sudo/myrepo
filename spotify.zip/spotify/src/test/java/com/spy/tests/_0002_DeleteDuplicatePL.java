package com.spy.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0002_DeleteDuplicatePL extends TestBase {

	@Test(enabled=false)
	public void deleteDupsPLs() {
		// TODO Auto-generated method stub

		Date date = new Date();
		SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy");
		String stringDate = DateFor.format(date);
		
		List<WebElement> dps = driver.findElements(By.xpath("//div[contains(text(),'25 Canadian Hits � "+stringDate+"')]"));
		
		Actions actions = new Actions(driver);

		for (WebElement dp : dps) {
			actions.contextClick(dp).perform();
			click("delMenu_XPATH");
			click("delBtn_XPATH");
		}

	}

}
