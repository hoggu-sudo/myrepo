package com.spy.tests;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0003_CreatePlayList extends TestBase {

	@Test
	public void createPlayList() {

		click("createPlayList_XPATH");
		click("myPlayList_XPATH");

		Date date = new Date();
		SimpleDateFormat DateFor = new SimpleDateFormat("dd/MM/yyyy");
		String stringDate = DateFor.format(date);	
		
		click("textBx_XPATH");

		type("textBx_XPATH", Keys.CONTROL + "a");
		type("textBx_XPATH", Keys.BACK_SPACE + "");

		type("textBx_XPATH", "25 Canadian Hits � " + stringDate);
		click("save_XPATH");
		log.debug("Creating playlist is completed");
	}
}













//List<WebElement> collect = driver.findElements(By.xpath("//div[text()='25 Canadian Hits � '" + stringDate + "']"));
//
//HashSet<WebElement> unique = new HashSet<WebElement>();
//
//for (WebElement one : collect) {
//	if (unique.contains(one)) {
//		unique.remove(one);
//	} else {
//		click("textBx_XPATH");
//
//		type("textBx_XPATH", Keys.CONTROL + "a");
//		type("textBx_XPATH", Keys.BACK_SPACE + "");
//
//		type("textBx_XPATH", "25 Canadian Hits � " + stringDate);
//		click("save_XPATH");
//	}
//}	