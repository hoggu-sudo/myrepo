package com.spy.tests;

import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0004_ClickHome extends TestBase {
	@Test
	public void clickHome() {
		
		click("home_XPATH");
		
		log.debug("Going to home is completed");
	}
}
