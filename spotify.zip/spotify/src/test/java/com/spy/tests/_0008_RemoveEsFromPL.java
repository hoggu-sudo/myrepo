package com.spy.tests;

import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0008_RemoveEsFromPL extends TestBase {

	@Test(enabled = false)
	public void removeExplicitSongs() {
		Actions ac = new Actions(driver);

		//List<WebElement> exs = driver.findElements(By.xpath("//span[@aria-label='Explicit']"));
		List<WebElement> exs = driver.findElements(By.xpath("//div[contains(@data-testid,'tracklist-row') and contains(@draggable,\"true\")]"));

		Collections.reverse(exs);

		for (WebElement x : exs) {
			if (x.getText().equals("E")) {
				System.out.println(x.getText());
				ac.contextClick(x).perform();
				click("removeFromPL_XPATH");
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		log.debug("Removing explicit songs is completed");
	}
}