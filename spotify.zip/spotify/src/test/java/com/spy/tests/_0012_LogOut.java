package com.spy.tests;

import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0012_LogOut extends TestBase{
	
	@Test
	public void LogOut() {
		click("idBtn_XPATH");
		click("logoutBtn_XPATH");
		
		log.debug("Logging out the application");
	}

}
