package com.spy.tests;

import org.testng.annotations.Test;

import com.spy.base.TestBase;

public class _0001_LognTest extends TestBase {

	@Test
	public void loginTest() {
		
		click("loginBtn1_XPATH");
		type("username_XPATH","hemu.oggu@gmail.com");
		type("password_XPATH","spotify@123");
		click("loginBtn2_XPATH");
		
		log.debug("Login test is completed");
	}
}
